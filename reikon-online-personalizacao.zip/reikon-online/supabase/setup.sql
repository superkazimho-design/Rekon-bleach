-- Execute no SQL Editor do Supabase. Configure primeiro Authentication > Providers > Anonymous.
create extension if not exists pgcrypto;
create table if not exists public.masters(user_id uuid primary key references auth.users(id) on delete cascade);
create table if not exists public.invites(id uuid primary key default gen_random_uuid(),token text unique not null,created_at timestamptz not null default now(),redeemed_at timestamptz,redeemed_by uuid references auth.users(id),revoked boolean not null default false);
create table if not exists public.characters(id uuid primary key default gen_random_uuid(),owner_id uuid not null references auth.users(id),data jsonb not null default '{}'::jsonb,created_at timestamptz not null default now(),updated_at timestamptz not null default now());
alter table public.masters enable row level security;
alter table public.invites enable row level security;
alter table public.characters enable row level security;
revoke all on public.masters from anon,authenticated;
create or replace function public.is_master() returns boolean language sql stable security definer set search_path='' as $$ select exists(select 1 from public.masters where user_id=(select auth.uid())) $$;
create or replace function public.has_access() returns boolean language sql stable security definer set search_path='' as $$ select public.is_master() or exists(select 1 from public.invites where redeemed_by=(select auth.uid()) and revoked=false) $$;
create or replace function public.create_invite() returns text language plpgsql security definer set search_path='' as $$ declare t text;begin if not public.is_master() then raise exception 'Apenas o mestre pode gerar tokens';end if;t:=encode(gen_random_bytes(24),'hex');insert into public.invites(token) values(t);return t;end $$;
create or replace function public.redeem_token(p_token text) returns boolean language plpgsql security definer set search_path='' as $$ declare affected integer;begin if auth.uid() is null then return false;end if;update public.invites set redeemed_at=now(),redeemed_by=auth.uid() where token=p_token and redeemed_at is null and revoked=false;get diagnostics affected=row_count;return affected=1;end $$;
revoke all on function public.is_master() from public;
revoke all on function public.has_access() from public;
revoke all on function public.create_invite() from public;
revoke all on function public.redeem_token(text) from public;
grant execute on function public.is_master() to authenticated;
grant execute on function public.has_access() to authenticated;
grant execute on function public.create_invite() to authenticated;
grant execute on function public.redeem_token(text) to authenticated;
create policy "master reads invites" on public.invites for select to authenticated using (public.is_master());
create policy "master revokes invites" on public.invites for update to authenticated using (public.is_master()) with check (public.is_master());
create policy "owner or master reads characters" on public.characters for select to authenticated using (public.has_access() and (owner_id=auth.uid() or public.is_master()));
create policy "authorized owner creates characters" on public.characters for insert to authenticated with check (public.has_access() and owner_id=auth.uid());
create policy "owner or master edits characters" on public.characters for update to authenticated using (public.has_access() and (owner_id=auth.uid() or public.is_master())) with check (public.has_access() and (owner_id=auth.uid() or public.is_master()));
create policy "owner or master deletes characters" on public.characters for delete to authenticated using (public.has_access() and (owner_id=auth.uid() or public.is_master()));
-- IMPORTANTE: Depois de criar sua conta mestre no Supabase Auth,
-- execute manualmente substituindo o UUID pelo ID REAL da sua conta:
-- insert into public.masters(user_id) values ('UUID-DA-SUA-CONTA');
