'use client';
import {useEffect,useState} from 'react';
import {usePathname,useRouter} from 'next/navigation';
import {supabase,configured} from '@/lib/supabase';
export default function AccessGate({children}:{children:React.ReactNode}){
 const path=usePathname(),router=useRouter();const [state,setState]=useState<'loading'|'allowed'|'denied'>('loading');
 useEffect(()=>{let alive=true;if(path==='/acesso'){setState('allowed');return}if(!configured||!supabase){setState('denied');return}const check=async()=>{const {data:{user}}=await supabase!.auth.getUser();if(!user){if(alive)setState('denied');return}const {data,error}=await supabase!.rpc('has_access');if(alive)setState(!error&&data?'allowed':'denied')};check();const {data:{subscription}}=supabase.auth.onAuthStateChange(()=>{setTimeout(check,0)});return()=>{alive=false;subscription.unsubscribe()}},[path]);
 if(state==='loading')return <div className="min-h-screen bg-[#0b0b0f] p-10 text-white">Verificando acesso espiritual...</div>;
 if(state==='denied')return <div className="flex min-h-screen flex-col items-center justify-center gap-5 bg-[#0b0b0f] p-6 text-center text-white"><h1 className="text-3xl font-black">PORTAL BLOQUEADO</h1><p className="max-w-md text-zinc-400">Somente jogadores autorizados pelo mestre podem entrar. {configured?'Entre com seu token.':'O mestre precisa configurar o Supabase antes de publicar.'}</p><button onClick={()=>router.push('/acesso')} className="rounded bg-red-600 px-6 py-3 font-bold">Ir para acesso</button></div>;
 return <>{children}</>;
}
