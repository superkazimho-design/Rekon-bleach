import './globals.css';
import AccessGate from '@/components/AccessGate';
export const metadata={title:'REIKON | Portal espiritual',description:'Portal privado do RPG'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="pt-BR"><body><AccessGate>{children}</AccessGate></body></html>}
